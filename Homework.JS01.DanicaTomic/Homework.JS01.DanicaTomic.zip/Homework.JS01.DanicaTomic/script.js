let tax = 0.05;
let price = 119.95;
let percent = tax * price;
console.log(percent);
let finalPrice = price + percent;
console.log(finalPrice);
let quantity = 30;
let result = finalPrice * quantity;
console.log(result);
